package game.sanguo.core;

import java.io.IOException;
import java.util.*;

/** Original51dd10 then5d3d40/5d3c90/5c4840, for the verified local recruitment caller. */
final class PcDebateOutcome {
    private static World.Officer ruler(World w,int owner)throws IOException{
        World.Officer found=null;for(World.Officer o:w.officers)if(o.owner==owner&&o.role==Strategy.Role.RULER){if(found!=null)throw new IOException("Original force has multiple ruler identities");found=o;}
        if(found==null)throw new IOException("Original force ruler identity is unknown");return found;
    }
    private static PcScenarioPeople.Person sourcePerson(World w,int id)throws IOException{
        for(PcScenarioPeople.Person p:PcScenarioPeople.saved(w))if(p.officerId==id)return p;
        throw new IOException("Original person identity is unknown");
    }
    static String error(World w,Contests.Session session){
        if(!PcNativeCampaignPolicy.enabled(w))return "此存档未记录完整原战役结算策略";
        if(session.diplomatic())return "原外交结果回调尚未完成核实";
        PcDebateCampaign c=session.nativeDebate;
        if(c==null||c.model.phase!=9)return "请先完成舌战及终局选择";
        if(c.model.state.terminalWinner<0||c.model.state.terminalWinner>1||c.model.outcome<0||c.model.outcome>3)return "原终局结果无效";
        try{prepare(w,session);}catch(IOException|IllegalArgumentException e){return e.getMessage();}return null;
    }
    private static final class Plan {
        World.Officer actor,target,newRuler,oldRuler;
        PcScenarioPeople.Person targetSource,newRulerSource,oldRulerSource;
        int oldOwner,winner,outcome,rawLoyalty;
        boolean sameFather;
        PcDebateSettlement.Result numeric;
    }
    private static Plan prepare(World w,Contests.Session session)throws IOException{
        Plan p=new Plan();p.actor=w.officer(session.leftRef);p.target=w.officer(session.rightRef);p.oldOwner=p.target.owner;
        p.winner=session.nativeDebate.model.state.terminalWinner;p.outcome=session.nativeDebate.model.outcome;
        if(p.actor.unitId!=-1||p.target.unitId!=-1)throw new IOException("该战役结算仅核实了本城登用调用者");
        World.Officer[] officers={p.actor,p.target};int[] merit=new int[2],xp=new int[2],injury=new int[2],owner=new int[2];boolean[] eligible=new boolean[2];
        int[] points=new int[w.factions.length];for(int i=0;i<points.length;i++)points[i]=w.campaign.points(i);
        for(int i=0;i<2;i++){World.Officer o=officers[i];merit[i]=w.government.merit(o.id);xp[i]=w.officerAbilities.experience(o.id,2);injury[i]=w.contests.injury(o.id);owner[i]=o.owner;eligible[i]=PcNativeCampaignPolicy.allowed(w,o.id);}
        // Original4a54a0 requires another active unit member with native skill84.
        // This actual caller admits city officers only, so neither has a unit party.
        p.numeric=PcDebateSettlement.calculate(p.winner,p.outcome,merit,xp,injury,owner,points,new boolean[]{false,false},eligible);
        if(p.winner==0){
            p.rawLoyalty=PcNativeCampaignPolicy.rawLoyalty(w,p.target.id);p.newRuler=ruler(w,session.owner);p.targetSource=sourcePerson(w,p.target.id);p.newRulerSource=sourcePerson(w,p.newRuler.id);
            p.sameFather=PcNativeParentPolicy.sameFather(w,p.target.id,p.newRuler.id);
            if(p.target.honor<1||p.target.honor>5)throw new IOException("当前义理超出已核实的原值映射");
            if(p.oldOwner>=0&&p.oldOwner!=session.owner){p.oldRuler=ruler(w,p.oldOwner);p.oldRulerSource=sourcePerson(w,p.oldRuler.id);if(p.oldRulerSource.field(45)<0||p.oldRulerSource.field(45)>4)throw new IOException("原旧君主野心不在核实范围");PcNativeCampaignPolicy.friendship(w,p.oldOwner,session.owner);}
        }
        return p;
    }
    static String settle(World w,Contests.Session session)throws IOException{
        Plan p=prepare(w,session);World.Officer[] officers={p.actor,p.target};
        for(int i=0;i<2;i++){
            World.Officer o=officers[i];w.government.merits.put(o.id,p.numeric.merit[i]);
            w.officerAbilities.gainExperience(o.id,2,p.numeric.intelligenceExperience[i]-w.officerAbilities.experience(o.id,2));
            if(p.numeric.injury[i]!=w.contests.injury(o.id))PcNativeHealthPolicy.setInjury(w,o.id,p.numeric.injury[i]);
        }
        for(int i=0;i<p.numeric.techniquePoints.length;i++)if(p.numeric.techniquePoints[i]!=w.campaign.points(i))w.campaign.setPoints(i,p.numeric.techniquePoints[i],TechniquePointsJournal.Cause.DEBATE,session.city,p.actor.id);
        if(p.winner!=0){callerReward(w,p,false);return p.actor.name+"舌战落败，登用未成功；已结算原经验、功绩及伤病";}
        w.strategy.releaseGovernor(p.target.id);w.government.allegianceChanged(p.target.id);
        w.government.prisoners.remove(p.target.id);
        p.target.owner=session.owner;p.target.cityId=session.city;p.target.role=Strategy.Role.OFFICER;p.target.lastRewardTurn=-1;p.target.acted=true;
        w.officerAbilities.refresh(p.target);
        int distance=Math.abs(p.target.affinity-p.newRuler.affinity),gap=Math.min(distance,150-distance);
        int loyalty=PcOfficerJoinRules.loyalty(p.rawLoyalty,gap,p.target.honor-1,p.targetSource.field(45),p.newRuler.charm,false,p.target.role==Strategy.Role.RULER,
            w.relations.spouse(p.target.id)==p.newRuler.id,w.relations.sworn(p.target.id,p.newRuler.id),w.relations.likes(p.target.id,p.newRuler.id),w.relations.dislikes(p.target.id,p.newRuler.id),p.sameFather,
            p.targetSource.field(49)==p.newRulerSource.field(49),p.targetSource.field(41)==p.newRulerSource.field(41));
        PcNativeCampaignPolicy.setLoyalty(w,p.target.id,loyalty);
        if(p.oldRuler!=null){
            PcMerchantRules.Random random=new PcMerchantRules.Random(PcNativeDebatePolicy.seed(w));
            int ambition=p.oldRulerSource.field(45);
            int penalty=(PcNativeCampaignPolicy.allied(w,p.oldOwner,session.owner)?5:8)+2*(ambition<=1?0:random.uniform(ambition));
            PcNativeDebatePolicy.setSeed(w,random.state);PcNativeCampaignPolicy.changeFriendship(w,p.oldOwner,session.owner,-penalty);
            PcNativeCampaignPolicy.ban(w,p.target.id,p.oldRulerSource.nativeId,6);
        }
        int request=20+p.target.charm/3;w.campaign.setPoints(session.owner,PcTechniquePoints.after(w.campaign.points(session.owner),request),TechniquePointsJournal.Cause.DEBATE,session.city,p.actor.id);
        // Original5d3c90 calls5c4840 before caller charm/politics experience;
        // this ordering matters when the persuader is also the new ruler.
        callerReward(w,p,true);
        return p.actor.name+"舌战获胜，"+p.target.name+"加入"+w.faction(session.owner)+"；原经验、功绩、伤病及登用结果已结算";
    }
    private static void callerReward(World w,Plan p,boolean success){
        w.government.merits.put(p.actor.id,Math.min(60000,w.government.merit(p.actor.id)+(success?200:100)));
        w.officerAbilities.gainExperience(p.actor.id,3,3);w.officerAbilities.gainExperience(p.actor.id,4,success?5:3);
    }
    private PcDebateOutcome(){}
}
