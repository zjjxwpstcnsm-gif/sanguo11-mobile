package game.sanguo.core;

/** Original4cf160 strict ordering. Admission and governor mutation are separate. */
final class PcGovernorOrder {
    static final class Candidate {
        final int nativeId,status,commandCapacity,leadership,war,merit;
        final boolean allowed;
        Candidate(int nativeId,boolean allowed,int status,int commandCapacity,int leadership,int war,int merit){
            // Original allowed-object predicate admits some constructed NPCs
            // with status-1. Eligibility is separate from this comparator.
            if(nativeId<0||nativeId>1099||status< -1||status>8||commandCapacity<0||commandCapacity>65535
                ||leadership<0||leadership>255||war<0||war>255||merit<0||merit>65535)
                throw new IllegalArgumentException("Original governor candidate outside native field range");
            this.nativeId=nativeId;this.allowed=allowed;this.status=status;this.commandCapacity=commandCapacity;
            this.leadership=leadership;this.war=war;this.merit=merit;
        }
    }
    static boolean earlier(Candidate a,Candidate b){
        if(!a.allowed||!b.allowed||a.nativeId==b.nativeId)return false;
        if((a.status<=1||b.status<=1)&&a.status!=b.status)return a.status<b.status;
        if(a.commandCapacity!=b.commandCapacity)return a.commandCapacity>b.commandCapacity;
        if(a.leadership!=b.leadership)return a.leadership>b.leadership;
        if(a.war!=b.war)return a.war>b.war;
        if(a.merit!=b.merit)return a.merit>b.merit;
        return a.nativeId<b.nativeId;
    }
    private PcGovernorOrder(){}
}
