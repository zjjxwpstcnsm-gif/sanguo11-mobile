package game.sanguo.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Explicit fresh-source runtime records. Restore reads the save, never a new catalog. */
public final class PcNativeCampaignPolicy {
    public static final String NAMESPACE="pc-native-campaign-state-v1";
    private static final int CATALOG=0x504e4331,SAVED=0x504e4332;
    private static final class Person {
        int id,nativeId,rawLoyalty,banNative,banMonths,captiveMonths,owner,displayed;
        boolean loyaltyKnown=true;
        String recordSha;
    }
    private static final class State {
        String sourceId,sourceSha,sourceVariant;
        int lastTurn=-1;
        final SortedMap<Integer,Person> people=new TreeMap<>();
        final int[][] friendship=new int[47][47];
        final boolean[][] allies=new boolean[47][47];
        final boolean[] forceValid=new boolean[47];
    }
    public static final class Facts {
        public final int nativeId,banRulerNativeId,banMonths,captiveMonths;
        public final Integer rawLoyalty;
        Facts(Person p,World.Officer o){nativeId=p.nativeId;banRulerNativeId=p.banNative;banMonths=p.banMonths;captiveMonths=p.captiveMonths;
            rawLoyalty=p.loyaltyKnown&&p.owner==o.owner&&p.displayed==o.loyalty?Integer.valueOf(p.rawLoyalty):null;}
    }
    static boolean enabled(World w){
        byte[] raw=w.extensions.get(NAMESPACE);
        return w.pcSourceFrame&&PcNativeDebatePolicy.enabled(w)&&raw!=null&&raw.length>=4&&java.nio.ByteBuffer.wrap(raw).getInt()==SAVED;
    }
    private static String hash(byte[] bytes)throws IOException{
        try{StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes))s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
        catch(NoSuchAlgorithmException e){throw new IOException(e);}
    }
    private static byte[] resource(String name,int max)throws IOException{
        try(InputStream input=PcNativeCampaignPolicy.class.getResourceAsStream(name)){
            if(input==null)throw new IOException("Original campaign state resource missing");
            ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];
            for(int n;(n=input.read(b))!=-1;){if(out.size()+n>max)throw new IOException("Original campaign state resource too large");out.write(b,0,n);}return out.toByteArray();
        }
    }
    static void initializeOpening(World w)throws IOException{
        if(!w.pcSourceFrame||w.turn!=0||w.commandRevision()!=0||w.contests.busy()||w.extensions.get(NAMESPACE)!=null||!PcNativeDebatePolicy.enabled(w))throw new IOException("Original campaign strategy needs explicit fresh source game");
        byte[] packed=resource("/pc-native-campaign/state.bin.gz",2*1024*1024);ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        try(InputStream in=new GZIPInputStream(new ByteArrayInputStream(packed))){byte[] b=new byte[8192];for(int n;(n=in.read(b))!=-1;){if(buffer.size()+n>4*1024*1024)throw new IOException("Original campaign state decoded resource too large");buffer.write(b,0,n);}}
        byte[] raw=buffer.toByteArray();if(!hash(raw).equals(new String(resource("/pc-native-campaign/index.txt",128),StandardCharsets.US_ASCII).trim()))throw new IOException("Original campaign state SHA differs");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));
        if(in.readInt()!=CATALOG||!PcOfficerInfo.text(in,64).equals(PcScenarioIdentity.EXE_SHA)||!PcOfficerInfo.text(in,64).matches("[0-9a-f]{64}"))throw new IOException("Original campaign state provenance differs");
        PcScenarioIdentity.Source identity=PcScenarioIdentity.saved(w);State chosen=null;
        int n=PcOfficerInfo.bounded(in.readInt(),16,16);
        for(int source=0;source<n;source++){
            State s=new State();s.sourceId=PcOfficerInfo.text(in,80);String path=PcOfficerInfo.text(in,1024);s.sourceVariant=PcOfficerInfo.text(in,300);s.sourceSha=PcOfficerInfo.text(in,64);
            boolean selected=s.sourceId.equals(identity.scenarioId);
            if(selected&&(!path.equals(identity.path)||!s.sourceSha.equals(identity.sha)||!s.sourceVariant.equals(identity.sourceVariant)||chosen!=null))throw new IOException("Original campaign state source differs");
            int count=PcOfficerInfo.bounded(in.readInt(),850,850);
            for(int j=0;j<count;j++){
                Person p=new Person();p.id=PcOfficerInfo.bounded(in.readInt(),-1,999999);p.nativeId=PcOfficerInfo.bounded(in.readInt(),0,849);p.recordSha=PcOfficerInfo.text(in,64);
                p.rawLoyalty=PcOfficerInfo.bounded(in.readInt(),0,255);p.banNative=PcOfficerInfo.bounded(in.readInt(),-1,1099);p.banMonths=PcOfficerInfo.bounded(in.readInt(),0,255);p.captiveMonths=PcOfficerInfo.bounded(in.readInt(),0,100);
                if(p.nativeId!=j||!p.recordSha.matches("[0-9a-f]{64}"))throw new IOException("Original campaign state person order differs");
                if(selected&&p.id>=0){World.Officer o=w.officer(p.id);if(o==null||s.people.put(p.id,p)!=null)throw new IOException("Original campaign state person missing");p.owner=o.owner;p.displayed=o.loyalty;}
            }
            if(PcOfficerInfo.bounded(in.readInt(),47,47)!=47)throw new IOException("Original force state count differs");
            for(int j=0;j<47;j++){
                if(in.readInt()!=j)throw new IOException("Original force state order differs");s.forceValid[j]=PcOfficerInfo.bounded(in.readInt(),0,1)==1;
                for(int k=0;k<47;k++){s.friendship[j][k]=PcOfficerInfo.bounded(in.readInt(),0,100);s.allies[j][k]=PcOfficerInfo.bounded(in.readInt(),0,1)==1;in.readInt();}
            }
            if(selected)chosen=s;
        }
        if(chosen==null||in.available()!=0||chosen.people.size()!=PcOfficerCampaignFacts.saved(w).size())throw new IOException("Original campaign source coverage incomplete");
        write(w,chosen);read(w);
    }
    private static State read(World w)throws IOException{
        byte[] raw=w.extensions.get(NAMESPACE);if(!enabled(w)||raw.length>256*1024)throw new IOException("Original campaign saved state missing/too large");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);
        State s=new State();if(in.readInt()!=SAVED)throw new IOException("Original campaign saved version unknown");
        s.sourceId=PcOfficerInfo.text(in,80);s.sourceSha=PcOfficerInfo.text(in,64);s.sourceVariant=PcOfficerInfo.text(in,300);
        if(source==null||!s.sourceId.equals(source.scenarioId)||!s.sourceSha.equals(source.sha)||!s.sourceVariant.equals(source.sourceVariant))throw new IOException("Original campaign saved source differs");
        s.lastTurn=PcOfficerInfo.bounded(in.readInt(),-1,w.turn);Map<Integer,PcScenarioPeople.Person> originals=new HashMap<>();for(PcScenarioPeople.Person p:PcScenarioPeople.saved(w))if(p.officerId>=0)originals.put(p.officerId,p);
        int n=PcOfficerInfo.bounded(in.readInt(),0,1100);if(n!=originals.size())throw new IOException("Original campaign saved roster differs");
        for(int i=0;i<n;i++){
            Person p=new Person();p.id=in.readInt();p.nativeId=PcOfficerInfo.bounded(in.readInt(),0,1099);p.recordSha=PcOfficerInfo.text(in,64);p.rawLoyalty=in.readUnsignedByte();p.banNative=PcOfficerInfo.bounded(in.readInt(),-1,1099);p.banMonths=in.readUnsignedByte();p.captiveMonths=PcOfficerInfo.bounded(in.readUnsignedByte(),0,100);p.owner=PcOfficerInfo.bounded(in.readInt(),-1,46);p.displayed=PcOfficerInfo.bounded(in.readInt(),0,100);p.loyaltyKnown=in.readBoolean();
            PcScenarioPeople.Person original=originals.get(p.id);if(original==null||original.nativeId!=p.nativeId||!original.recordSha.equals(p.recordSha)||w.officer(p.id)==null||s.people.put(p.id,p)!=null)throw new IOException("Original campaign saved identity differs");
        }
        for(int i=0;i<47;i++){s.forceValid[i]=in.readBoolean();for(int j=0;j<47;j++){s.friendship[i][j]=PcOfficerInfo.bounded(in.readUnsignedByte(),0,100);s.allies[i][j]=in.readBoolean();}}
        if(in.available()!=0)throw new IOException("Original campaign saved tail unknown");return s;
    }
    private static void write(World w,State s)throws IOException{
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);out.writeInt(SAVED);PcOfficerInfo.text(out,s.sourceId);PcOfficerInfo.text(out,s.sourceSha);PcOfficerInfo.text(out,s.sourceVariant);out.writeInt(s.lastTurn);out.writeInt(s.people.size());
        for(Person p:s.people.values()){out.writeInt(p.id);out.writeInt(p.nativeId);PcOfficerInfo.text(out,p.recordSha);out.writeByte(p.rawLoyalty);out.writeInt(p.banNative);out.writeByte(p.banMonths);out.writeByte(p.captiveMonths);out.writeInt(p.owner);out.writeInt(p.displayed);out.writeBoolean(p.loyaltyKnown);}
        for(int i=0;i<47;i++){out.writeBoolean(s.forceValid[i]);for(int j=0;j<47;j++){out.writeByte(s.friendship[i][j]);out.writeBoolean(s.allies[i][j]);}}w.extensions.put(NAMESPACE,buffer.toByteArray());
    }
    public static Facts facts(World w,int officer)throws IOException{if(!enabled(w))return null;Person p=read(w).people.get(officer);return p==null?null:new Facts(p,w.officer(officer));}
    public static Map<Integer,Facts> facts(World w)throws IOException{
        if(!enabled(w))return Collections.emptyMap();Map<Integer,Facts> result=new TreeMap<>();
        for(Person p:read(w).people.values())result.put(p.id,new Facts(p,w.officer(p.id)));
        return Collections.unmodifiableMap(result);
    }
    static int rawLoyalty(World w,int officer)throws IOException{Facts f=facts(w,officer);if(f==null||f.rawLoyalty==null)throw new IOException("Current original raw loyalty is unknown after an unverified mutation");return f.rawLoyalty;}
    static void setLoyalty(World w,int officer,int value)throws IOException{
        if(value<0||value>255)throw new IOException("Original raw loyalty outside byte range");State s=read(w);Person p=s.people.get(officer);World.Officer o=w.officer(officer);if(p==null||o==null)throw new IOException("Original loyalty participant missing");
        p.rawLoyalty=value;p.owner=o.owner;p.displayed=Math.min(100,value);p.loyaltyKnown=true;o.loyalty=p.displayed;write(w,s);
    }
    static void invalidateLoyalty(World w,int officer){if(!enabled(w))return;try{State s=read(w);Person p=s.people.get(officer);if(p!=null){p.loyaltyKnown=false;write(w,s);}}catch(IOException e){throw new IllegalStateException(e);}}
    static boolean allied(World w,int a,int b)throws IOException{State s=read(w);return a>=0&&b>=0&&a<47&&b<47&&s.forceValid[a]&&s.forceValid[b]&&s.allies[a][b];}
    static int friendship(World w,int a,int b)throws IOException{State s=read(w);if(a<0||a>=47||b<0||b>=47)throw new IOException("Original force reference outside range");return s.friendship[a][b];}
    static void changeFriendship(World w,int a,int b,int delta)throws IOException{
        State s=read(w);if(a<0||b<0||a>=47||b>=47||a==b||!s.forceValid[a]||!s.forceValid[b])return;
        int value=(int)Math.max(0,Math.min(100,(long)s.friendship[a][b]+delta));s.friendship[a][b]=value;s.friendship[b][a]=value;write(w,s);
    }
    static void ban(World w,int officer,int rulerNative,int months)throws IOException{
        if(rulerNative<-1||rulerNative>1099||months<0||months>255)throw new IOException("Original employment ban invalid");State s=read(w);Person p=s.people.get(officer);if(p==null)throw new IOException("Original employment ban participant missing");p.banNative=months==0?-1:rulerNative;p.banMonths=months;write(w,s);
    }
    static boolean allowed(World w,int id){Lifecycle.Life life=w.life.life(id);return w.officer(id)!=null&&life!=null&&life.state()!=Lifecycle.State.UNAPPEARED&&life.state()!=Lifecycle.State.SOURCE_WAIT&&life.state()!=Lifecycle.State.DEAD;}
    static void tick(World w){if(!enabled(w))return;try{
        State s=read(w);if(s.lastTurn==w.turn)return;s.lastTurn=w.turn;PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);int days=source.day-1+w.turn*10;
        if(days%30==0){Map<Integer,Person> natives=new HashMap<>();for(Person p:s.people.values())natives.put(p.nativeId,p);
            for(Person p:s.people.values())if(allowed(w,p.id)){
                if(w.government.captive(p.id))p.captiveMonths=Math.min(100,p.captiveMonths+1);
                if(p.banMonths>0){Person ruler=natives.get(p.banNative);if(ruler==null||!allowed(w,ruler.id)||--p.banMonths==0){p.banNative=-1;p.banMonths=0;}}
            }
        }write(w,s);
    }catch(IOException e){throw new IllegalStateException(e);}}
    static void validate(World w)throws IOException{if(enabled(w)){if(!PcNativeDebatePolicy.enabled(w))throw new IOException("Original campaign state requires its saved native policy");read(w);}}
    private PcNativeCampaignPolicy(){}
}
