package game.sanguo.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Explicit source army references and original4bca30 election, saved separately. */
public final class PcNativeGovernorPolicy {
    static final String NAMESPACE="pc-native-governor-policy-v1";
    private static final int CATALOG=0x504e4731,SAVED=0x504e4732;
    private static final class District {
        int nativeId,owner,number,leader,policy,permissions,targetKind,target,loadedPoints;boolean allowed;
    }
    private static final class Site {int nativeId,id,owner,army;}
    private static final class Person {int nativeId,id,owner,army,home,location,status;String recordSha;}
    private static final class State {
        String sourceId,path,variant,sha;
        final Map<Integer,District> districts=new TreeMap<>();
        final Map<Integer,Site> sites=new TreeMap<>();
        final Map<Integer,Person> people=new TreeMap<>();
    }
    static boolean enabled(World w){byte[] b=w.extensions.get(NAMESPACE);return w.pcSourceFrame&&b!=null&&b.length>=4&&java.nio.ByteBuffer.wrap(b).getInt()==SAVED;}
    private static String hash(byte[] raw)throws IOException{try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(raw));}catch(NoSuchAlgorithmException e){throw new IOException(e);}}
    private static byte[] resource(String name,int limit)throws IOException{
        try(InputStream in=PcNativeGovernorPolicy.class.getResourceAsStream(name)){
            if(in==null)throw new IOException("Original army/governor resource missing");byte[] b=in.readNBytes(limit+1);if(b.length>limit)throw new IOException("Original army/governor resource too large");return b;
        }
    }
    static void initializeOpening(World w)throws IOException{
        if(!PcNativeCampaignPolicy.enabled(w)||w.turn!=0||w.commandRevision()!=0||w.extensions.get(NAMESPACE)!=null)throw new IOException("Original governor policy requires explicit fresh source");
        byte[] raw;try(InputStream in=new GZIPInputStream(new ByteArrayInputStream(resource("/pc-native-governance/governance.bin.gz",2*1024*1024)))){raw=in.readNBytes(4*1024*1024+1);}
        if(raw.length>4*1024*1024||!hash(raw).equals(new String(resource("/pc-native-governance/index.txt",128),StandardCharsets.US_ASCII).trim()))throw new IOException("Original governor resource SHA differs");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));
        if(in.readInt()!=CATALOG||!PcOfficerInfo.text(in,64).equals(PcScenarioIdentity.EXE_SHA))throw new IOException("Original governor executable identity differs");
        for(int i=0;i<3;i++)if(!PcOfficerInfo.text(in,64).matches("[0-9a-f]{64}"))throw new IOException("Original governor proof identity invalid");
        int count=PcOfficerInfo.bounded(in.readInt(),1,16);State chosen=null;PcScenarioIdentity.Source identity=PcScenarioIdentity.saved(w);
        for(int i=0;i<count;i++){State s=readState(in);if(s.sourceId.equals(identity.scenarioId)){if(chosen!=null)throw new IOException("Original governor source duplicate");chosen=s;}}
        if(chosen==null||in.available()!=0)throw new IOException("Original governor source not yet imported");validateIdentity(w,chosen);write(w,chosen);
    }
    private static State readState(DataInputStream in)throws IOException{
        State s=new State();s.sourceId=PcOfficerInfo.text(in,80);s.path=PcOfficerInfo.text(in,1024);s.variant=PcOfficerInfo.text(in,300);s.sha=PcOfficerInfo.text(in,64);
        if(in.readInt()!=47)throw new IOException("Original army domain incomplete");
        for(int i=0;i<47;i++){
            District d=new District();d.nativeId=PcOfficerInfo.bounded(in.readInt(),0,46);d.allowed=PcOfficerInfo.bounded(in.readInt(),0,1)!=0;
            d.owner=PcOfficerInfo.bounded(in.readInt(),-1,46);d.number=PcOfficerInfo.bounded(in.readInt(),-1,47);d.leader=PcOfficerInfo.bounded(in.readInt(),-1,1099);
            d.policy=PcOfficerInfo.bounded(in.readInt(),-1,4);d.permissions=in.readInt();d.targetKind=in.readInt();d.target=in.readInt();d.loadedPoints=PcOfficerInfo.bounded(in.readInt(),0,255);
            if(d.nativeId!=i)throw new IOException("Original army order differs");s.districts.put(i,d);
        }
        if(in.readInt()!=87)throw new IOException("Original governor site domain incomplete");
        for(int i=0;i<87;i++){Site c=new Site();c.nativeId=PcOfficerInfo.bounded(in.readInt(),0,86);c.id=PcOfficerInfo.bounded(in.readInt(),0,999999);c.owner=PcOfficerInfo.bounded(in.readInt(),-1,46);c.army=PcOfficerInfo.bounded(in.readInt(),-1,46);if(c.nativeId!=i)throw new IOException("Original site order differs");s.sites.put(i,c);}
        if(in.readInt()!=850)throw new IOException("Original governor person domain incomplete");
        for(int i=0;i<850;i++){Person p=new Person();p.nativeId=PcOfficerInfo.bounded(in.readInt(),0,849);p.id=PcOfficerInfo.bounded(in.readInt(),-1,999999);p.recordSha=PcOfficerInfo.text(in,64);
            p.owner=PcOfficerInfo.bounded(in.readInt(),-1,46);p.army=PcOfficerInfo.bounded(in.readInt(),-1,46);p.home=PcOfficerInfo.bounded(in.readInt(),-1,86);p.location=PcOfficerInfo.bounded(in.readInt(),-1,1099);p.status=PcOfficerInfo.bounded(in.readInt(),-1,8);
            if(p.nativeId!=i||!p.recordSha.matches("[0-9a-f]{64}"))throw new IOException("Original governor person order differs");s.people.put(i,p);
        }return s;
    }
    private static void write(World w,State s)throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeInt(SAVED);
        for(String text:new String[]{s.sourceId,s.path,s.variant,s.sha})PcOfficerInfo.text(out,text);out.writeInt(47);
        for(District d:s.districts.values()){out.writeInt(d.nativeId);out.writeInt(d.allowed?1:0);for(int n:new int[]{d.owner,d.number,d.leader,d.policy,d.permissions,d.targetKind,d.target,d.loadedPoints})out.writeInt(n);}
        out.writeInt(87);for(Site c:s.sites.values())for(int n:new int[]{c.nativeId,c.id,c.owner,c.army})out.writeInt(n);
        out.writeInt(850);for(Person p:s.people.values()){out.writeInt(p.nativeId);out.writeInt(p.id);PcOfficerInfo.text(out,p.recordSha);for(int n:new int[]{p.owner,p.army,p.home,p.location,p.status})out.writeInt(n);}w.extensions.put(NAMESPACE,bytes.toByteArray());
    }
    private static State read(World w)throws IOException{
        if(!enabled(w))throw new IOException("Original governor saved policy missing");DataInputStream in=new DataInputStream(new ByteArrayInputStream(w.extensions.get(NAMESPACE)));if(in.readInt()!=SAVED)throw new IOException("Original governor saved version unknown");State s=readState(in);if(in.available()!=0)throw new IOException("Original governor saved trailing bytes");validateIdentity(w,s);return s;
    }
    private static void validateIdentity(World w,State s)throws IOException{
        PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);if(source==null||!source.scenarioId.equals(s.sourceId)||!source.path.equals(s.path)||!source.sha.equals(s.sha)||!source.sourceVariant.equals(s.variant))throw new IOException("Saved governor source identity differs");
        Map<Integer,PcScenarioPeople.Person> people=new HashMap<>();for(PcScenarioPeople.Person p:PcScenarioPeople.saved(w))people.put(p.nativeId,p);Set<Integer> ids=new HashSet<>();
        for(Person p:s.people.values()){PcScenarioPeople.Person original=people.get(p.nativeId);if(original==null||original.officerId!=p.id||!original.recordSha.equals(p.recordSha)||p.id>=0&&(!ids.add(p.id)||w.officer(p.id)==null))throw new IOException("Saved governor person identity differs");}
        Map<Integer,Integer> sourceSites=PcScenarioPeople.savedSiteIdentities(w);
        Set<Integer> siteIds=new HashSet<>();for(Site c:s.sites.values())if(!Objects.equals(sourceSites.get(c.nativeId),c.id)||!siteIds.add(c.id)||w.city(c.id)==null)throw new IOException("Saved governor site identity differs");
    }
    private static Site site(State s,int id){for(Site c:s.sites.values())if(c.id==id)return c;return null;}
    private static Person person(State s,int id){for(Person p:s.people.values())if(p.id==id)return p;return null;}
    public static final class Assignment {
        public final int nativeId,districtNativeId,districtOwner,districtNumber,leaderNativeId;
        public final Integer leaderOfficerId;
        Assignment(State s,Person p,District d){nativeId=p.nativeId;districtNativeId=d.nativeId;districtOwner=d.owner;districtNumber=d.number;leaderNativeId=d.leader;Person leader=s.people.get(d.leader);leaderOfficerId=leader!=null&&leader.id>=0?Integer.valueOf(leader.id):null;}
    }
    /** Live known army references from saved policy; source initial fields stay separate. */
    public static Map<Integer,Assignment> assignments(World w)throws IOException{
        if(!enabled(w))return Collections.emptyMap();State s=read(w);Map<Integer,Assignment> result=new TreeMap<>();
        for(Person p:s.people.values())if(p.id>=0){World.Officer o=w.officer(p.id);District d=s.districts.get(p.army);if(o.owner==p.owner&&d!=null&&d.allowed&&d.owner==o.owner)result.put(p.id,new Assignment(s,p,d));}
        return Collections.unmodifiableMap(result);
    }
    private static boolean resident(World w,World.Officer o,World.City c){
        return w.governance.resident(o,c)&&o.cityId==c.id;
    }
    private static int status(World w,State s,Person p,World.Officer o){
        Lifecycle.Life life=w.life.life(o.id);if(life==null||life.state()==Lifecycle.State.DEAD)return 8;
        if(life.state()==Lifecycle.State.UNAPPEARED||life.state()==Lifecycle.State.SOURCE_WAIT)return 6;
        if(life.state()==Lifecycle.State.UNDISCOVERED)return 7;if(w.government.captive(o.id))return 5;
        if(o.owner<0)return 4;if(o.role==Strategy.Role.RULER)return 0;
        District d=s.districts.get(p.army);if(d!=null&&d.allowed&&d.owner==o.owner&&d.leader==p.nativeId)return 1;
        return o.role==Strategy.Role.GOVERNOR?2:3;
    }
    static void recruit(World w,int id,int destination)throws IOException{
        State s=read(w);Person p=person(s,id);Site c=site(s,destination);World.Officer o=w.officer(id);World.City city=w.city(destination);
        District d=c==null?null:s.districts.get(c.army);
        if(p==null||o==null||c==null||city==null||d==null||!d.allowed||d.owner!=city.owner||city.owner!=c.owner)throw new IOException("原登用军团连接未知");
        p.owner=o.owner;p.army=c.army;p.home=c.nativeId;p.location=c.nativeId;p.status=3;write(w,s);
    }
    static String recruitmentError(World w,int id,int destination){try{
        State s=read(w);Site c=site(s,destination);World.City city=w.city(destination);District d=c==null?null:s.districts.get(c.army);
        return person(s,id)==null||c==null||city==null||d==null||!d.allowed||d.owner!=city.owner||city.owner!=c.owner?"原登用军团连接未知":null;
    }catch(IOException e){return e.getMessage();}}
    static void reconcile(World w,boolean announce){try{
        State s=read(w);Set<Integer> appointed=new HashSet<>(),touchedSites=new HashSet<>();
        for(Site reference:s.sites.values()){
            World.City city=w.city(reference.id);if(city.owner!=reference.owner)continue;
            touchedSites.add(city.id);
            World.Officer chosen=null;PcGovernorOrder.Candidate best=null;World.Officer priority=null;
            for(Person p:s.people.values()){
                World.Officer o=p.id<0?null:w.officer(p.id);if(o==null||o.owner<0||o.owner>41||o.owner!=city.owner||o.owner!=p.owner||p.army!=reference.army||p.home!=reference.nativeId||p.location!=reference.nativeId||!resident(w,o,city))continue;
                int nativeStatus=status(w,s,p,o);if(nativeStatus<0||nativeStatus>3)continue;
                if(nativeStatus<=1){priority=o;continue;}
                PcGovernorOrder.Candidate candidate=new PcGovernorOrder.Candidate(p.nativeId,true,nativeStatus,w.government.commandLimit(o.id),o.leadership,o.war,Math.min(65535,w.government.merit(o.id)));
                if(best==null||PcGovernorOrder.earlier(candidate,best)){best=candidate;chosen=o;}
            }
            if(priority!=null)chosen=priority;int next=chosen==null?-1:chosen.id;
            if(city.governorId!=next){city.governorId=next;if(announce&&chosen!=null)w.note(city.name+"按原军团与驻地规则任命"+chosen.name+"为太守");}
            if(next>=0)appointed.add(next);
        }
        for(Person p:s.people.values())if(p.id>=0){World.Officer o=w.officer(p.id);if(o.role==Strategy.Role.RULER)continue;
            District d=s.districts.get(p.army);boolean commander=d!=null&&d.allowed&&d.owner==o.owner&&d.leader==p.nativeId;
            if(appointed.contains(p.id)&&!commander)o.role=Strategy.Role.GOVERNOR;
            else if(o.role==Strategy.Role.GOVERNOR&&touchedSites.contains(o.cityId))o.role=o.owner<0?Strategy.Role.UNAFFILIATED:Strategy.Role.OFFICER;
        }
    }catch(IOException e){throw new IllegalStateException(e);}}
    static void validate(World w)throws IOException{if(enabled(w))read(w);}
    private PcNativeGovernorPolicy(){}
}
