package game.sanguo.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Original internal references are saved separately from public family links. */
final class PcNativeParentPolicy {
    static final String NAMESPACE="pc-native-parent-references-v1";
    private static final int CATALOG=0x504e5031,SAVED=0x504e5032;
    // The original serializer emits these constructed slots with zero consumed
    // bytes. Its SHA is the empty-byte SHA, never a verified person identity.
    private static final String EMPTY_RECORD_SHA="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    private static final class Person {int nativeId,id,father,publicFather;boolean valid;String recordSha;}
    private static final class State {String sourceId,sourceSha,variant;final Map<Integer,Person> people=new TreeMap<>();}
    private static String hash(byte[] raw)throws IOException{
        try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(raw));}catch(NoSuchAlgorithmException e){throw new IOException(e);}
    }
    private static byte[] resource(String name,int limit)throws IOException{
        try(InputStream in=PcNativeParentPolicy.class.getResourceAsStream(name)){
            if(in==null)throw new IOException("Original internal reference resource missing");byte[] raw=in.readNBytes(limit+1);
            if(raw.length>limit)throw new IOException("Original internal reference resource exceeds limit");return raw;
        }
    }
    static boolean enabled(World w){byte[] raw=w.extensions.get(NAMESPACE);return w.pcSourceFrame&&raw!=null&&raw.length>=4&&java.nio.ByteBuffer.wrap(raw).getInt()==SAVED;}
    static void initializeOpening(World w)throws IOException{
        if(!PcNativeCampaignPolicy.enabled(w)||w.turn!=0||w.commandRevision()!=0||w.extensions.get(NAMESPACE)!=null)throw new IOException("Original references require explicit fresh source policy");
        byte[] packed=resource("/pc-native-parents/references.bin.gz",2*1024*1024),raw;
        try(InputStream in=new GZIPInputStream(new ByteArrayInputStream(packed))){raw=in.readNBytes(2*1024*1024+1);}
        if(raw.length>2*1024*1024||!hash(raw).equals(new String(resource("/pc-native-parents/index.txt",128),StandardCharsets.US_ASCII).trim()))throw new IOException("Original internal reference SHA differs");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));
        if(in.readInt()!=CATALOG||!PcOfficerInfo.text(in,64).equals(PcScenarioIdentity.EXE_SHA)||!PcOfficerInfo.text(in,64).equals("4a457201caa09a755ca152f854d07f6751a00e8b571e4712601435c02d46f7a6"))throw new IOException("Original reference provenance differs");
        PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);State chosen=null;
        if(in.readInt()!=16)throw new IOException("Original reference source count differs");
        for(int i=0;i<16;i++){
            State s=new State();s.sourceId=PcOfficerInfo.text(in,80);String path=PcOfficerInfo.text(in,1024);s.variant=PcOfficerInfo.text(in,300);s.sourceSha=PcOfficerInfo.text(in,64);
            boolean selected=s.sourceId.equals(source.scenarioId);
            if(selected&&(chosen!=null||!path.equals(source.path)||!s.variant.equals(source.sourceVariant)||!s.sourceSha.equals(source.sha)))throw new IOException("Original reference source identity differs");
            if(in.readInt()!=1100)throw new IOException("Original reference domain incomplete");
            for(int j=0;j<1100;j++){
                Person p=new Person();p.nativeId=PcOfficerInfo.bounded(in.readInt(),0,1099);p.id=PcOfficerInfo.bounded(in.readInt(),-1,999999);p.recordSha=PcOfficerInfo.text(in,64);p.father=PcOfficerInfo.bounded(in.readInt(),-1,1099);p.valid=PcOfficerInfo.bounded(in.readInt(),0,1)!=0;
                if(p.nativeId!=j||j<850&&!p.recordSha.matches("[0-9a-f]{64}")||j>=850&&(!p.recordSha.equals(EMPTY_RECORD_SHA)||p.id!=-1))throw new IOException("Original reference record order differs");
                if(selected){if(p.id>=0){if(w.officer(p.id)==null)throw new IOException("Original reference identity missing");p.publicFather=w.relations.parent(p.id,false);}s.people.put(j,p);}
            }
            if(selected)chosen=s;
        }
        if(chosen==null||in.available()!=0)throw new IOException("Original reference resource not exact");validateIdentity(w,chosen);write(w,chosen);
    }
    private static void validateIdentity(World w,State s)throws IOException{
        PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);
        if(source==null||!source.scenarioId.equals(s.sourceId)||!source.sha.equals(s.sourceSha)||!source.sourceVariant.equals(s.variant)||s.people.size()!=1100)throw new IOException("Saved original reference source differs");
        Map<Integer,PcScenarioPeople.Person> originals=new HashMap<>();for(PcScenarioPeople.Person p:PcScenarioPeople.saved(w))originals.put(p.nativeId,p);
        Set<Integer> ids=new HashSet<>();
        for(Person p:s.people.values()){
            if(p.nativeId<850){PcScenarioPeople.Person original=originals.get(p.nativeId);if(original==null||original.officerId!=p.id||!original.recordSha.equals(p.recordSha))throw new IOException("Saved original reference identity differs");}
            else if(p.id!=-1||!p.recordSha.equals(EMPTY_RECORD_SHA))throw new IOException("Constructed original reference has unproved runtime identity");
            if(p.id>=0&&(!ids.add(p.id)||w.officer(p.id)==null||p.publicFather>=0&&w.officer(p.publicFather)==null))throw new IOException("Saved original reference runtime identity invalid");
        }
    }
    private static void write(World w,State s)throws IOException{
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buffer);out.writeInt(SAVED);PcOfficerInfo.text(out,s.sourceId);PcOfficerInfo.text(out,s.sourceSha);PcOfficerInfo.text(out,s.variant);out.writeInt(1100);
        for(Person p:s.people.values()){out.writeInt(p.nativeId);out.writeInt(p.id);PcOfficerInfo.text(out,p.recordSha);out.writeInt(p.father);out.writeInt(p.publicFather);out.writeBoolean(p.valid);}w.extensions.put(NAMESPACE,buffer.toByteArray());
    }
    private static State read(World w)throws IOException{
        if(!enabled(w))throw new IOException("此存档未记录原内部父亲引用策略");DataInputStream in=new DataInputStream(new ByteArrayInputStream(w.extensions.get(NAMESPACE)));
        if(in.readInt()!=SAVED)throw new IOException("Saved original reference version unknown");State s=new State();s.sourceId=PcOfficerInfo.text(in,80);s.sourceSha=PcOfficerInfo.text(in,64);s.variant=PcOfficerInfo.text(in,300);
        if(in.readInt()!=1100)throw new IOException("Saved original reference domain incomplete");
        for(int i=0;i<1100;i++){Person p=new Person();p.nativeId=PcOfficerInfo.bounded(in.readInt(),0,1099);p.id=PcOfficerInfo.bounded(in.readInt(),-1,999999);p.recordSha=PcOfficerInfo.text(in,64);p.father=PcOfficerInfo.bounded(in.readInt(),-1,1099);p.publicFather=PcOfficerInfo.bounded(in.readInt(),-1,999999);p.valid=in.readBoolean();if(p.nativeId!=i)throw new IOException("Saved original reference order differs");s.people.put(i,p);}
        if(in.available()!=0)throw new IOException("Saved original reference trailing bytes");validateIdentity(w,s);return s;
    }
    static final class References {
        private final Map<Integer,Person> mapped;
        private final Set<Integer> edited;
        References(World w,State s)throws IOException{
            Map<Integer,Person> byId=new TreeMap<>();Set<Integer> changed=new HashSet<>();for(Person p:s.people.values())if(p.id>=0){
                if(w.relations.parent(p.id,false)!=p.publicFather)changed.add(p.id);byId.put(p.id,p);
            }mapped=Collections.unmodifiableMap(byId);edited=Collections.unmodifiableSet(changed);
        }
        boolean sameFather(int left,int right)throws IOException{
        Person a=mapped.get(left),b=mapped.get(right);
        if(a==null||b==null)throw new IOException("原内部关系参与人物身份未知");
        if(edited.contains(left)||edited.contains(right))throw new IOException("已编辑父亲关系，原内部引用转换尚未核实");
        return a.father>=0&&a.father<=1099&&b.valid&&a.nativeId!=b.nativeId&&a.father==b.father;
        }
    }
    static References references(World w)throws IOException{return new References(w,read(w));}
    static boolean sameFather(World w,int left,int right)throws IOException{return references(w).sameFather(left,right);}
    static void validate(World w)throws IOException{if(enabled(w))read(w);}
    private PcNativeParentPolicy(){}
}
