package game.sanguo.core;
import java.io.*;
import java.util.*;

/** Immutable per-source original records. Live abilities/assignments remain in World.
 * Extra/NPC/unmapped identities are explicit; no slot arithmetic becomes an officer ID. */
public final class PcScenarioPeople {
    public static final String NAMESPACE="pc-scenario-people-v1";
    private static final int MAGIC=0x50535031;
    private PcScenarioPeople(){}
    public static final class Person {
        public final int nativeId,officerId;
        public final boolean strictIdentity;
        public final String originalName,nameRaw,recordSha,courtesy,courtesyRaw;
        public final Map<Integer,Integer> fields;
        public final List<String> unknown;
        Person(int nativeId,int id,boolean strict,String name,String raw,String sha,String courtesy,String courtesyRaw,Map<Integer,Integer> fields,List<String> unknown){
            this.nativeId=nativeId;officerId=id;strictIdentity=strict;originalName=name;nameRaw=raw;recordSha=sha;
            this.courtesy=courtesy;this.courtesyRaw=courtesyRaw;
            this.fields=Collections.unmodifiableMap(new TreeMap<>(fields));this.unknown=List.copyOf(unknown);
        }
        public int field(int key)throws IOException{Integer n=fields.get(key);if(n==null)throw new IOException("原人物字段缺失："+nativeId+"/"+key);return n;}
    }
    public static List<Person> saved(World w)throws IOException{
        if(!w.pcSourceFrame)return Collections.emptyList();byte[] raw=w.extensions.get(NAMESPACE);if(raw==null)return Collections.emptyList();
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));if(in.readInt()!=MAGIC)throw new IOException("原人物状态快照版本未知");
        int n=PcOfficerInfo.bounded(in.readInt(),0,1100);List<Person> result=new ArrayList<>();Set<Integer> nativeIds=new HashSet<>(),ids=new HashSet<>();
        for(int i=0;i<n;i++){Person p=read(in);if(!nativeIds.add(p.nativeId)||p.officerId>=0&&!ids.add(p.officerId))throw new IOException("原人物身份重复");result.add(p);}
        if(in.available()!=0)throw new IOException("原人物状态尾部未知");return List.copyOf(result);
    }
    private static final String OPENING_NAMESPACE="pc-source-opening-record-v1";
    static void attachOpening(World w,PcScenarioCatalog.Source source)throws IOException{
        if(!w.pcSourceFrame||w.extensions.get(OPENING_NAMESPACE)!=null)throw new IOException("原开局快照只能在来源新局建立");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeInt(0x50534f31);out.writeUTF(source.identity.scenarioId);out.writeUTF(source.identity.sha);
        out.writeInt(source.sites.size());for(PcScenarioCatalog.Site site:source.sites){out.writeInt(site.nativeId);out.writeInt(site.id);out.writeUTF(site.name);writeFields(out,site.fields);out.writeInt(site.rate);out.writeInt(site.parent);}
        out.writeInt(source.forces.size());for(PcScenarioCatalog.Force force:source.forces){out.writeInt(force.nativeId);out.writeBoolean(force.valid);writeFields(out,force.fields);}
        w.extensions.put(OPENING_NAMESPACE,bytes.toByteArray());
    }
    private static void writeFields(DataOutputStream out,Map<Integer,Integer> fields)throws IOException{
        out.writeInt(fields.size());for(Map.Entry<Integer,Integer> e:fields.entrySet()){out.writeInt(e.getKey());out.writeInt(e.getValue());}
    }
    /** Original immutable force records, from the save rather than the current catalog. */
    static Map<Integer,Integer> savedSiteIdentities(World w)throws IOException{
        byte[] raw=w.extensions.get(OPENING_NAMESPACE);if(!w.pcSourceFrame||raw==null)return Collections.emptyMap();
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);
        if(in.readInt()!=0x50534f31||source==null||!in.readUTF().equals(source.scenarioId)||!in.readUTF().equals(source.sha))throw new IOException("原据点快照来源不一致");
        int count=PcOfficerInfo.bounded(in.readInt(),87,87);Map<Integer,Integer> sites=new TreeMap<>();Set<Integer> ids=new HashSet<>();
        for(int i=0;i<count;i++){int nativeId=in.readInt(),id=PcOfficerInfo.bounded(in.readInt(),0,999999);if(nativeId!=i||!ids.add(id))throw new IOException("原据点快照身份重复");sites.put(nativeId,id);in.readUTF();readFields(in);PcOfficerInfo.bounded(in.readInt(),0,255);PcOfficerInfo.bounded(in.readInt(),0,999999);}
        count=PcOfficerInfo.bounded(in.readInt(),47,47);for(int i=0;i<count;i++){if(in.readInt()!=i)throw new IOException("原势力快照引用错误");in.readBoolean();readFields(in);}
        if(in.available()!=0)throw new IOException("原据点快照尾部未知");return Collections.unmodifiableMap(sites);
    }
    public static Map<Integer,Map<Integer,Integer>> savedForces(World w)throws IOException{
        if(!w.pcSourceFrame)return Collections.emptyMap();byte[] raw=w.extensions.get(OPENING_NAMESPACE);if(raw==null)return Collections.emptyMap();
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(raw));PcScenarioIdentity.Source source=PcScenarioIdentity.saved(w);
        if(in.readInt()!=0x50534f31||source==null||!in.readUTF().equals(source.scenarioId)||!in.readUTF().equals(source.sha))throw new IOException("原开局快照来源不一致");
        int n=PcOfficerInfo.bounded(in.readInt(),87,87);for(int i=0;i<n;i++){if(in.readInt()!=i||in.readInt()<0)throw new IOException("原据点快照引用错误");in.readUTF();readFields(in);PcOfficerInfo.bounded(in.readInt(),0,255);PcOfficerInfo.bounded(in.readInt(),0,999999);}
        n=PcOfficerInfo.bounded(in.readInt(),47,47);Map<Integer,Map<Integer,Integer>> result=new TreeMap<>();for(int i=0;i<n;i++){if(in.readInt()!=i)throw new IOException("原势力快照引用错误");boolean valid=in.readBoolean();Map<Integer,Integer> fields=readFields(in);if(valid)result.put(i,fields);}
        if(in.available()!=0)throw new IOException("原开局快照尾部未知");return Collections.unmodifiableMap(result);
    }
    private static Map<Integer,Integer> readFields(DataInputStream in)throws IOException{
        int n=PcOfficerInfo.bounded(in.readInt(),0,400);Map<Integer,Integer> result=new TreeMap<>();for(int i=0;i<n;i++){int key=PcOfficerInfo.bounded(in.readInt(),0,400);if(result.put(key,in.readInt())!=null)throw new IOException("原快照字段重复");}return Collections.unmodifiableMap(result);
    }
    static Person read(DataInputStream in)throws IOException{
        int nativeId=PcOfficerInfo.bounded(in.readInt(),0,1099),id=PcOfficerInfo.bounded(in.readInt(),-1,999999);boolean strict=in.readBoolean();
        String name=PcOfficerInfo.text(in,1024),raw=PcOfficerInfo.text(in,128),sha=PcOfficerInfo.text(in,64),courtesy=PcOfficerInfo.text(in,1024),courtesyRaw=PcOfficerInfo.text(in,128);
        if(!sha.matches("[0-9a-f]{64}")||!raw.matches("(?:[0-9a-f]{2})*")||id>=0&&raw.isEmpty()||strict&&id<0)throw new IOException("原人物字节身份无效");
        int n=PcOfficerInfo.bounded(in.readInt(),0,300);Map<Integer,Integer> fields=new TreeMap<>();
        for(int i=0;i<n;i++){int key=PcOfficerInfo.bounded(in.readInt(),0,300);if(fields.put(key,in.readInt())!=null)throw new IOException("原人物字段重复");}
        n=PcOfficerInfo.bounded(in.readInt(),0,128);List<String> unknown=new ArrayList<>();for(int i=0;i<n;i++)unknown.add(PcOfficerInfo.text(in,256));
        return new Person(nativeId,id,strict,name,raw,sha,courtesy,courtesyRaw,fields,unknown);
    }
    static void write(DataOutputStream out,Person p)throws IOException{
        out.writeInt(p.nativeId);out.writeInt(p.officerId);out.writeBoolean(p.strictIdentity);PcOfficerInfo.text(out,p.originalName);PcOfficerInfo.text(out,p.nameRaw);PcOfficerInfo.text(out,p.recordSha);PcOfficerInfo.text(out,p.courtesy);PcOfficerInfo.text(out,p.courtesyRaw);
        out.writeInt(p.fields.size());for(Map.Entry<Integer,Integer> e:p.fields.entrySet()){out.writeInt(e.getKey());out.writeInt(e.getValue());}
        out.writeInt(p.unknown.size());for(String gap:p.unknown)PcOfficerInfo.text(out,gap);
    }
    static void attach(World w,List<Person> people)throws IOException{
        if(!w.pcSourceFrame||w.turn!=0||w.extensions.get(NAMESPACE)!=null)throw new IOException("原人物状态只能明确新局附加");
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);out.writeInt(MAGIC);out.writeInt(people.size());for(Person p:people)write(out,p);w.extensions.put(NAMESPACE,bytes.toByteArray());
    }
}
