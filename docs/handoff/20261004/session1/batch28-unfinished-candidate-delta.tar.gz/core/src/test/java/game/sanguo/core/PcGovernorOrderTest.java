package game.sanguo.core;

import java.nio.file.*;
import java.util.*;

/** Original executable fixtures, including actual Source0 and controlled cases. */
public final class PcGovernorOrderTest {
    private static PcGovernorOrder.Candidate candidate(String[] row,int at){
        return new PcGovernorOrder.Candidate(Integer.parseInt(row[at]),row[at+1].equals("1"),
            Integer.parseInt(row[at+2]),Integer.parseInt(row[at+3]),Integer.parseInt(row[at+4]),
            Integer.parseInt(row[at+5]),Integer.parseInt(row[at+6]));
    }
    public static void main(String[] args)throws Exception{
        List<String> lines=Files.readAllLines(Path.of(args[0]));int checks=0;
        if(!lines.remove(0).equals("# original-sha256=95e20e50948f8cd5ad4112f2b43c101547a3526f10572b2c646db35cac4022b8"))throw new AssertionError("Original fixture provenance differs");
        for(String line:lines){String[] row=line.split("\\t");
            if(row.length!=15||PcGovernorOrder.earlier(candidate(row,0),candidate(row,7))!=row[14].equals("1"))throw new AssertionError("Original governor comparison:"+checks);
            checks++;
        }
        if(checks!=1416)throw new AssertionError("Original fixture count differs");
        System.out.println("PASS PcGovernorOrder "+checks+" original Source0/comparator fixtures; residency, capacity derivation, mutation and APK remain separate");
    }
}
