package game.sanguo.core;

import java.nio.file.*;
import java.util.*;

/** Complete original election fixtures plus saved-world/native RNG boundaries. */
public final class PcNativeGovernorPolicyTest {
    private static int checks;
    private static void require(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        Path folder=Path.of(args[0]);List<String> elections=Files.readAllLines(folder.resolve("election-fixtures.tsv")),capacities=Files.readAllLines(folder.resolve("capacity-fixtures.tsv"));
        require(elections.remove(0).equals(capacities.remove(0)),"same original proof manifest");Set<String> sourceIds=new TreeSet<>();for(String line:elections)sourceIds.add(line.split("\\t")[0]);
        for(String source:sourceIds){World w=PcScenarioCatalog.preview(source);PcNativeDebatePolicy.initializeOpening(w);require(PcNativeGovernorPolicy.enabled(w),"explicit fresh policy");
            byte[] initial=SaveCodec.encode(w);require(Arrays.equals(initial,SaveCodec.encode(SaveCodec.decode(initial))),"complete initial save/dual RNG exact");
            int nativeSeed=PcNativeDebatePolicy.seed(w);long campaignSeed=w.strategy.getRandomState();
            for(String line:capacities){String[] v=line.split("\\t");if(!v[0].equals(source))continue;int id=Integer.parseInt(v[1]);World.Officer o=w.officer(id);
                require(w.government.commandLimit(id)==Integer.parseInt(v[3]),"original effective command capacity:"+line);
                require(o.leadership==Integer.parseInt(v[4])&&o.war==Integer.parseInt(v[5]),"same original option0/current ability:"+line);
            }
            w.governance.reconcile(false);
            for(String line:elections){String[] v=line.split("\\t");if(v[0].equals(source))require(w.city(Integer.parseInt(v[2])).governorId==Integer.parseInt(v[4]),"complete original election:"+line);}
            require(PcNativeDebatePolicy.seed(w)==nativeSeed&&w.strategy.getRandomState()==campaignSeed,"election consumes neither RNG");
            byte[] settled=SaveCodec.encode(w);World restored=SaveCodec.decode(settled);require(Arrays.equals(settled,SaveCodec.encode(restored)),"whole elected world and dual RNG exact");
            restored.governance.reconcile(false);require(Arrays.equals(settled,SaveCodec.encode(restored)),"election idempotent after restore");
        }
        World old=SaveCodec.decode(Files.readAllBytes(Path.of(args[1])));byte[] before=SaveCodec.encode(old);require(!PcNativeGovernorPolicy.enabled(old),"genuine old39 no backfill");
        require(Arrays.equals(before,SaveCodec.encode(SaveCodec.decode(before))),"old whole bytes and RNG exact");
        World w=PcScenarioCatalog.preview(PcScenarioCatalog.all().get(0).identity.scenarioId);PcNativeDebatePolicy.initializeOpening(w);
        PcNativeGovernorPolicy.Assignment actor=PcNativeGovernorPolicy.assignments(w).get(10116);
        require(actor.districtNativeId==0&&actor.districtOwner==2&&actor.districtNumber==1&&actor.leaderOfficerId==10365,"raw global army0 versus force display1 and verified ruler ID");
        require(!PcNativeGovernorPolicy.assignments(w).containsKey(10222),"unemployed actor has no fabricated army");
        System.out.println("PASS PcNativeGovernorPolicy "+checks+" original entire selected-source elections/effective capacities/current values/fullsave dualRNG/old no-backfill; remaining sources and APK separate");
    }
}
