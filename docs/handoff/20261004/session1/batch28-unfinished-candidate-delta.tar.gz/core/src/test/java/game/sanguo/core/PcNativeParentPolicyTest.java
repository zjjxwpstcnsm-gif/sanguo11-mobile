package game.sanguo.core;
import java.nio.file.*;
import java.util.*;

/** Actual16 source reference fixtures and complete saved-state boundaries. */
public final class PcNativeParentPolicyTest {
    private static int checks;
    private static void require(boolean b,String message){checks++;if(!b)throw new AssertionError(message);}
    public static void main(String[] args)throws Exception{
        List<String> lines=Files.readAllLines(Path.of(args[0]));require(lines.remove(0).equals("# original-sha256=4a457201caa09a755ca152f854d07f6751a00e8b571e4712601435c02d46f7a6"),"fixture provenance");
        List<PcScenarioCatalog.Source> sources=PcScenarioCatalog.all();
        for(int i=0;i<16;i++){
            World w=PcScenarioCatalog.preview(sources.get(i).identity.scenarioId);PcNativeDebatePolicy.initializeOpening(w);
            require(PcNativeParentPolicy.enabled(w),"fresh policy");byte[] before=SaveCodec.encode(w);World restored=SaveCodec.decode(before);
            require(Arrays.equals(before,SaveCodec.encode(restored)),"entire World and dual RNG exact roundtrip");
            PcNativeParentPolicy.References refs=PcNativeParentPolicy.references(restored);
            for(String line:lines){String[] v=line.split("\\t");if(Integer.parseInt(v[0])!=i)continue;
                require(refs.sameFather(Integer.parseInt(v[1]),Integer.parseInt(v[2]))==v[3].equals("1"),"original sibling predicate:"+line);
            }
            require(Arrays.equals(before,SaveCodec.encode(restored)),"bulk query leaves whole authority/RNG unchanged");
        }
        World old=SaveCodec.decode(Files.readAllBytes(Path.of(args[1])));byte[] before=SaveCodec.encode(old);
        require(!PcNativeParentPolicy.enabled(old),"genuine previous39 no backfill");require(Arrays.equals(before,SaveCodec.encode(SaveCodec.decode(before))),"old entire bytes/RNG exact");
        World w=PcScenarioCatalog.preview(sources.get(0).identity.scenarioId);PcNativeDebatePolicy.initializeOpening(w);
        require(!PcNativeParentPolicy.sameFather(w,10222,10365),"two unknown public parents preserve distinct native self references");
        w.relations.people.computeIfAbsent(10222,id->new Relations.Person()).father=10365;
        boolean rejected=false;try{PcNativeParentPolicy.sameFather(w,10222,10365);}catch(java.io.IOException e){rejected=true;}require(rejected,"edited public relation never silently reuses original internal reference");
        require(!PcNativeParentPolicy.sameFather(w,10116,10365),"unrelated family edit does not replace other original references");
        System.out.println("PASS PcNativeParentPolicy "+checks+" actual16-source original sibling fixtures/full-save dualRNG/old no-backfill/edited relation rejection; APK separate");
    }
}
