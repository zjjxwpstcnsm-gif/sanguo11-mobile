package game.sanguo.core;
import java.nio.file.*;
import java.util.*;
import game.sanguo.api.*;
import game.sanguo.runtime.*;

/** Actual source city trigger/typed cards/one-time settlement/full World and RNG/cold play. */
public final class PcDebateOutcomeCampaignTest {
    static int checks;
    static void require(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static void turn(GameSession game,World control)throws Exception{
        TurnTicket ticket=game.beginTurn();World computed=SaveCodec.decode(ticket.initial());
        require(control.nextTurn().ok&&computed.nextTurn().ok&&game.commitTurn(ticket,computed),"normal turn transaction after settlement");
        require(Arrays.equals(game.captureSave(),SaveCodec.encode(control)),"full World/dual RNG turn parity");
    }
    static void progress(GameSession game,World control)throws Exception{
        ContestSnapshot dto=game.contest();byte[] before=game.captureSave();Contests.Session s=control.contests.current();PcDebateCampaign.Facts f=s.nativeDebate();
        require(dto.contestId==s.id()&&dto.revision==s.revision()&&dto.phase==f.phase,"same saved contest DTO");
        require(Arrays.equals(before,game.captureSave()),"contest query preserves complete save and RNG");
        ContestCommand input;World.Result result;
        if(f.waitingCard){int slot=-1;for(int i=1;i<f.hand.size();i++)if(f.cardErrors.get(i).isEmpty()){slot=i;break;}if(slot<0)slot=0;
            input=ContestCommand.card(game.state(),s.id(),s.revision(),slot);result=control.contests.debateCard(s.id(),s.revision(),slot);
        }else{input=ContestCommand.finishDebate(game.state(),s.id(),s.revision(),true);result=control.contests.finishDebate(s.id(),s.revision(),true);}
        require(result.ok,"actual direct native input/settlement");require(game.execute(input).ok(),"typed native input/settlement");
        byte[] after=game.captureSave();require(Arrays.equals(after,SaveCodec.encode(control)),"entire campaign and both RNGs match direct control");
        require(!game.execute(input).ok()&&Arrays.equals(after,game.captureSave()),"duplicate/stale input never settles again");
    }
    public static void main(String[] args)throws Exception{
        Path folder=Path.of(args[1]);
        if(args[0].equals("win-cold")){
            byte[] middle=Files.readAllBytes(folder.resolve("winning-settled.sg11"));World control=SaveCodec.decode(middle);
            try(GameSession game=new GameSession(SaveCodec.decode(middle))){require(Arrays.equals(middle,game.captureSave()),"new JVM exact winning settled save");require(game.contest().kind==ContestSnapshot.Kind.NONE&&game.officers().officer(10222).owner==2,"cold winning source officer DTO and normal campaign");for(int i=0;i<3;i++)turn(game,control);require(Arrays.equals(Files.readAllBytes(folder.resolve("winning-continued.sg11")),game.captureSave()),"winning cold ordinary play continuation");}
            System.out.println("PASS PcDebateOutcomeWinningCold "+checks);return;
        }
        if(args[0].equals("win")){
            byte[] terminal=Files.readAllBytes(folder.resolve("normal-source-win-terminal.sg11"));World control=SaveCodec.decode(terminal);
            require(control.contests.current().nativeDebate.model.state.terminalWinner==0,"normal source winning terminal, no numerical edits");
            int governor=control.city(control.officer(10116).cityId).governorId;
            int actorMerit=control.government.merit(10116),targetMerit=control.government.merit(10222);
            try(GameSession game=new GameSession(SaveCodec.decode(terminal))){
                require(game.contest().settlementAvailable,"same DTO offers actual winning settlement");progress(game,control);
                require(!control.contests.busy()&&game.contest().kind==ContestSnapshot.Kind.NONE,"winning settlement returns to normal game");
                require(control.officer(10222).owner==2&&control.officer(10222).role==Strategy.Role.OFFICER,"actual successful allegiance transfer");
                require(PcNativeCampaignPolicy.facts(control,10222).rawLoyalty==94&&control.officer(10222).loyalty==94,"actual known raw/display loyalty with current ruler charisma");
                require(control.government.merit(10116)==Math.min(60000,actorMerit+400)&&control.government.merit(10222)==Math.min(60000,targetMerit+10),"separate verified battle/caller merit deltas; prior trigger reward remains separately unverified");
                require(control.officerAbilities.experience(10116,2)==30&&control.officerAbilities.experience(10116,3)==3&&control.officerAbilities.experience(10116,4)==5&&control.officerAbilities.experience(10222,2)==1,"original battle and caller experience separated from base");
                require(control.contests.injury(10222)==1,"original terminal injury persists in saved strategy");
                require(control.city(control.officer(10116).cityId).governorId==governor,"record source governor result pending original complete-context comparison");
                Files.write(folder.resolve("winning-settled.sg11"),game.captureSave());for(int i=0;i<3;i++)turn(game,control);Files.write(folder.resolve("winning-continued.sg11"),game.captureSave());
            }
            System.out.println("PASS PcDebateOutcomeWin "+checks+" normal winning terminal/typed one-time transfer/merit XP/raw loyalty/injury/fullWorld+dualRNG/three turns; complete original governor/contexts pending");return;
        }
        if(args[0].equals("cold")){
            byte[] middle=Files.readAllBytes(folder.resolve("settled-mid.sg11"));World control=SaveCodec.decode(middle);
            try(GameSession game=new GameSession(SaveCodec.decode(middle))){require(Arrays.equals(middle,game.captureSave()),"new JVM exact settled save");for(int i=0;i<3;i++)turn(game,control);require(Arrays.equals(Files.readAllBytes(folder.resolve("settled-expected.sg11")),game.captureSave()),"independent process ordinary play continuation");}
            System.out.println("PASS PcDebateOutcomeCold "+checks);return;
        }
        Files.createDirectories(folder);
        int sourceIndex=0;
        for(PcScenarioCatalog.Source source:PcScenarioCatalog.all()){
            World sourceWorld=PcScenarioCatalog.preview(source.identity.scenarioId);PcNativeDebatePolicy.initializeOpening(sourceWorld);
            require(PcNativeCampaignPolicy.enabled(sourceWorld),"explicit fresh native source strategy");byte[] bytes=SaveCodec.encode(sourceWorld);
            Map<Integer,PcNativeCampaignPolicy.Facts> currentFacts=PcNativeCampaignPolicy.facts(sourceWorld);for(PcOfficerCampaignFacts.Fact p:PcOfficerCampaignFacts.saved(sourceWorld).values())require(currentFacts.get(p.officerId).rawLoyalty==p.initialRawLoyalty,"all per-source original raw values retain checked record identity");
            require(Arrays.equals(bytes,SaveCodec.encode(SaveCodec.decode(bytes))),"entire native state roundtrip");sourceIndex++;
        }
        require(sourceIndex==16,"all16 distinct sources with670 mapped records each");
        byte[] old=Files.readAllBytes(folder.resolve("old-native-start.sg11"));
        try(GameSession previous=new GameSession(SaveCodec.decode(old))){require(!PcNativeCampaignPolicy.enabled(SaveCodec.decode(previous.captureSave())),"genuine old native39 strategy is not backfilled");previous.contest();require(Arrays.equals(old,previous.captureSave()),"old native39 complete bytes and RNG stay exact");}
        String source=PcScenarioCatalog.all().get(0).identity.scenarioId;World w=PcScenarioCatalog.load(source,2,23);PcNativeDebatePolicy.initializeOpening(w);World control=SaveCodec.decode(SaveCodec.encode(w));
        int city=w.officer(10116).cityId;require(control.contests.persuade(city,10116,10222).ok,"normal unmodified source0 city persuasion");
        try(GameSession game=new GameSession(w)){
            LegacyView view=game.legacyView();require(game.legacy(view.draft,()->view.draft.contests.persuade(city,10116,10222)).ok,"real authority city trigger");require(Arrays.equals(game.captureSave(),SaveCodec.encode(control)),"full native trigger parity");
            int inputs=0;while(control.contests.busy()){require(inputs++<101,"bounded original full debate");progress(game,control);}
            require(game.contest().kind==ContestSnapshot.Kind.NONE,"finished contest leaves normal campaign playable");require(!PcNativeCampaignPolicy.enabled(SaveCodec.decode(old)),"old stored policy still absent");
            require(PcNativeCampaignPolicy.facts(control,10222).rawLoyalty!=null,"recruitment writes known original raw loyalty");
            Files.write(folder.resolve("settled-mid.sg11"),game.captureSave());for(int i=0;i<3;i++)turn(game,control);Files.write(folder.resolve("settled-expected.sg11"),game.captureSave());
        }
        System.out.println("PASS PcDebateOutcomeCampaign "+checks+" actual trigger/cards/one-time settlement/fullWorld+dualRNG/all16 states/ordinary continuation; device and remaining original caller policies pending");
    }
}
