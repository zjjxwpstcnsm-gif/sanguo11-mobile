from pathlib import Path
import json,struct
from inspect_pc_debate_flow import NativeDebateFlow
from pc_original_pe_data import load_original_data
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_EIP,UC_X86_REG_ESP,UC_X86_REG_ECX,UC_X86_REG_EAX
root=Path('/Users/paopao/Downloads/San11pk整合版/San11pk 超级整合版');exe=(root/'san11pk.exe').read_bytes();src=json.loads(Path('docs/handoff/20261004/session1/source-manifest.json').read_text())['scenarios'][0]
w=NativeDebateFlow(root,exe).world;load_original_data(w.u);w.load((root/'Media/scenario/Scenario.s11').read_bytes(),True);w.load((root/src['sourcePath']).read_bytes());w.call(0x73c500);w.call(0x73c2b0)
for f,v in zip([0x4826e0,0x482700,0x482720],src['date']):w.call(f,v,receiver=w.root)
w.call(0x4827b0,0,receiver=w.root);w.call(0x493400,receiver=w.root,count=50000000)
site=w.call(0x490d00,0,receiver=w.root);recent=[];calls=[]
def trace(u,ip,size,data):
 recent.append([hex(ip),hex(u.reg_read(UC_X86_REG_ECX)),hex(u.reg_read(UC_X86_REG_EAX))]);recent[:]=recent[-30:]
 if ip in [0x5d1f30,0x4866f0,0x491770,0x490a10,0x49dab0,0x47a630,0x4195d0]:calls.append(dict(ip=hex(ip),ecx=hex(u.reg_read(UC_X86_REG_ECX)),stack=bytes(u.mem_read(u.reg_read(UC_X86_REG_ESP),24)).hex()))
h=w.u.hook_add(UC_HOOK_CODE,trace);report=dict(sitePointer=hex(site),siteBefore=bytes(w.u.mem_read(site,0x80)).hex(),completeGoal=False)
try:report['originalCost']=w.call(0x5d1f30,site)
except Exception as e:report.update(error=repr(e),ip=hex(w.u.reg_read(UC_X86_REG_EIP)),invalid=w.invalid)
finally:w.u.hook_del(h);report.update(calls=calls,recent=recent);Path('out/session-b/recruitment-cost-trace.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
