package game.sanguo.core;
import java.util.*;import java.nio.file.*;import java.io.*;
public final class PcGovernorOpeningAudit {
 public static void main(String[] a)throws Exception{
  Map<String,Map<Integer,int[]>> expected=new HashMap<>();for(String line:Files.readAllLines(Path.of(a[0]))){if(line.startsWith("sourceId"))continue;String[]v=line.split("\\t");expected.computeIfAbsent(v[0],k->new HashMap<>()).put(Integer.parseInt(v[1]),new int[]{Integer.parseInt(v[2]),Integer.parseInt(v[3]),Integer.parseInt(v[4])});}
  int total=0,diff=0,unknown=0;System.out.println("source\tnativeSite\truntimeSite\tcurrentGovernor\toriginalNativeGovernor\tverifiedExpectedRuntime\towner\tdistrictNative");
  for(var source:PcScenarioCatalog.all()){
   World w=PcScenarioCatalog.preview(source.identity.scenarioId);byte[]before=SaveCodec.encode(w);Map<Integer,Integer> nativeIds=new HashMap<>();for(var p:PcScenarioPeople.saved(w))if(p.officerId>=0)nativeIds.put(p.nativeId,p.officerId);
   DataInputStream input=new DataInputStream(new ByteArrayInputStream(w.extensions.get("pc-source-opening-record-v1")));if(input.readInt()!=0x50534f31||!input.readUTF().equals(w.scenarioId)||!input.readUTF().equals(w.dataHash))throw new AssertionError("saved source identity");int n=input.readInt();if(n!=87)throw new AssertionError("site domain");
   for(int index=0;index<n;index++){int nativeSite=input.readInt(),siteId=input.readInt();input.readUTF();int fields=input.readInt();for(int f=0;f<fields;f++){input.readInt();input.readInt();}input.readInt();input.readInt();if(nativeSite!=index)throw new AssertionError("native site order");int[]e=expected.get(source.identity.scenarioId).get(nativeSite);if(e==null)throw new AssertionError("missing original site");World.City city=w.city(siteId);Integer target=e[0]<0?Integer.valueOf(-1):nativeIds.get(e[0]);total++;if(target==null){unknown++;System.out.println(source.identity.path+"\t"+nativeSite+"\t"+siteId+"\t"+city.governorId+"\t"+e[0]+"\tunknown\t"+e[1]+"\t"+e[2]);}else if(city.governorId!=target){diff++;System.out.println(source.identity.path+"\t"+nativeSite+"\t"+siteId+"\t"+city.governorId+"\t"+e[0]+"\t"+target+"\t"+e[1]+"\t"+e[2]);}}
   if(!Arrays.equals(before,SaveCodec.encode(w)))throw new AssertionError("Audit changed World/RNG");
  }
  if(total!=1392)throw new AssertionError("actual comparison coverage "+total);System.err.println("sites="+total+" verifiedIdentityDifferences="+diff+" unknownIdentity="+unknown+"; independent original election versus current source opening, no controller/AP/governance restoration claim");
 }
}
